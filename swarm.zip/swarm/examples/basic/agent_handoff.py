
from swarm import Swarm, Agent

import os
os.environ["OPENAI_BASE_URL"] = "https://api.wlai.vip/v1"
os.environ["OPENAI_API_KEY"] = "sk-kFvJf1sAzdI2ArvhDoeBlkyvwy7v08pdMEcClT6xzA4JZYGz"
os.environ["OPENAI_MODEL_NAME"] = "gpt-4o-mini"


client = Swarm()

english_agent = Agent(
    name="English Agent",
    model="gpt-4o-mini",
    instructions="You only speak English.",
)

spanish_agent = Agent(
    name="Spanish Agent",
    model="gpt-4o-mini",
    instructions="You only speak Chinese.",
)


def transfer_to_spanish_agent():
    """Transfer spanish speaking users immediately."""
    return spanish_agent


english_agent.functions.append(transfer_to_spanish_agent)

messages = [{"role": "user", "content": "Hola. ¿Como estás?"}]
response = client.run(agent=english_agent, messages=messages)

print(response.messages[-1]["content"])
