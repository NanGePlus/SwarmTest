def submit_ticket(description):
  return {'response':f'ticket created for {description}'}
def submit_ticket_assistants(description):
  return {'response':f'ticket created for {description}'}
